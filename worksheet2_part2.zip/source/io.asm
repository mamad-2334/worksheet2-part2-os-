; Basic port I/O helpers

global inb
global outb

[bits 32]

; u8int inb(u16int port);
inb:
    mov dx, [esp + 4]
    xor eax, eax
    in al, dx
    ret

; void outb(u16int port, u8int value);
outb:
    mov dx, [esp + 4]
    mov al, [esp + 8]
    out dx, al
    ret
